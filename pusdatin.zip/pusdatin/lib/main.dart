
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pusdatin/Controller/PlaceController.dart';
import 'package:provider/provider.dart';
import 'package:pusdatin/View/Splashcreen.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => PlaceController()),
      
    ],
    child: const MyApp(),
    ));

    Provider.debugCheckInvalidValueType = null;

}


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(
          title: 'PUSDATIN',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          
        // home: const MyHomePage(title: 'Flutter Demo Home Page'),
          initialRoute: "/",
          routes: {
            // splashscreen
            '/': (context) => const SplashScreen(),
            //login & daftar
            
           
          },
        );
  }
}


