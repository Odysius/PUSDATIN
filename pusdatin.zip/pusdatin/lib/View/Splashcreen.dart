import 'dart:async';
import 'package:flutter/material.dart';
import 'package:pusdatin/Controller/PlaceController.dart';
import 'package:pusdatin/View/Home.dart';
import 'package:provider/provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({ Key? key }) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState()  {
    super.initState();
    startSplashScreen();
    Provider.of<PlaceController>(context, listen: false).tampilPosisiGPS();
  }

  startSplashScreen() async {
    var duration = const Duration(seconds: 1);
    // initDynamicLinks();
    return Timer(duration, () async {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Home()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return
      Container(
        color: Colors.white,
        child:  
          Center(
            child: AnimatedSize(
              curve: Curves.elasticInOut,
                duration: const Duration(seconds:1),
                child: 
                  AnimatedOpacity(
                    opacity: 1.0,
                    duration: const Duration(seconds: 3),
                    curve: Curves.elasticOut,
                    child: Image.asset('assets/pusdatin.png',
                    width: MediaQuery.of(context).size.width*0.3,
                      fit: BoxFit.cover),
                  )
              ),
          )
      );
  }
}