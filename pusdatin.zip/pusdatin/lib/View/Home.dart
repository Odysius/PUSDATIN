import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class Home extends StatefulWidget {
  const Home({ Key? key }) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
 late GoogleMapController mapController;
  final LatLng targetLocation = LatLng(0.7893, 113.9213);
  final LatLng targetLocation2 = LatLng(3.5918, 98.6811);
  final LatLng targetLocation3 = LatLng(3.5836, 98.6718);
  final LatLng targetLocation4 = LatLng(3.5924, 98.6632);
  List<Marker> markers = [];
@override
  void initState() {
    super.initState();
    loadCustomMarkerIcon();
  }
  
   Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        title: Text('PUSDATIN DATA', style: TextStyle(color: Colors.black,),),
      ),
      body: GoogleMap(
        mapToolbarEnabled: true,
        zoomGesturesEnabled: true,
        zoomControlsEnabled: true,
        onMapCreated: (controller) {
          setState(() {
            mapController = controller;
          });
        },
        initialCameraPosition: CameraPosition(
          target: targetLocation,
          zoom: 3.0,
        ),
        markers: Set.from(markers),
      ),
    );;
   }

   Future<void> loadCustomMarkerIcon() async {
    final ByteData data = await rootBundle.load('assets/people.png');
    final Uint8List bytes = data.buffer.asUint8List();

    setState(() {
      markers = [
       Marker(
            markerId: MarkerId('targetMarker2'),
            position: targetLocation2,
           
            icon: BitmapDescriptor.fromBytes(bytes,size: Size(10, 10)),
            infoWindow: InfoWindow(
              title: 'Target Location',
              snippet: 'This is the desired location',
            ),
          ),
          Marker(
            markerId: MarkerId('targetMarker3'),
            position: targetLocation3,
            
            icon: BitmapDescriptor.fromBytes(bytes,size: Size(10, 10)),
            infoWindow: InfoWindow(
              title: 'Target Location',
              snippet: 'This is the desired location',
            ),
          ),
          Marker(
            markerId: MarkerId('targetMarker4'),
            position: targetLocation4,
            icon: BitmapDescriptor.fromBytes(bytes,size: Size(10, 10)),
            infoWindow: InfoWindow(
              title: 'Target Location',
              snippet: 'This is the desired location',
            ),
          ),
        // Add more markers as needed
      ];
    });
  }

}