import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class PlaceController with ChangeNotifier  {
  
  late Position positionsd;
  static double latitude =0.0;
  static double longitude=0.0;
  String prov = "";
  String city = "";
  String kecamatan = "";
  String kelurahan = "";
  String nation = "";
  
 void tampilPosisiGPS() async {
    if(Geolocator.checkPermission()==true){
      positionsd = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      latitude = positionsd.latitude;
      longitude = positionsd.longitude;
      getAddressFromLatLang(latitude.toString(),longitude.toString());
    }else{
      await Geolocator.requestPermission();
        positionsd = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        latitude = positionsd.latitude;
        longitude = positionsd.longitude;
        getAddressFromLatLang(latitude.toString(),longitude.toString());
    } 
    
  }

   getAddressFromLatLang(String lat, String long) async {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        double.parse(lat),
        double.parse(long)); //AddressController.latitude,AddressController.longitude);
      Placemark place = placemarks[0];
  
        prov = place.administrativeArea!;
        city = place.subAdministrativeArea!;
        kecamatan = place.locality!;
        kelurahan = place.subLocality!;
        nation = place.country!;
  }
}