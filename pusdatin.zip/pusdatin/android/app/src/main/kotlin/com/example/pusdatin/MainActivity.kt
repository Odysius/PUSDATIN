package com.example.pusdatin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
